package demo;

import org.apache.hadoop.conf.Configuration;

public class anyConf {
	
	Configuration conf = null;
	
	public anyConf() {
		// TODO Auto-generated constructor stub
		this.conf=new Configuration(true);   
	}

	public static Configuration getBasicConf() {
		// TODO Auto-generated method stub
		
		Configuration conf = new Configuration(true);
		
		conf.setBoolean("mapreduce.app-submission.cross-platform", true);
		conf.set("hadoop.tmp.dir", "/home/acrush/softdir/hadoop/tmp");
		conf.set("fs.defaultFS", "hdfs://192.168.0.1:8020/");
		conf.set("mapreduce.framework.name", "yarn");
		conf.set("yarn.resourcemanager.address", "192.168.0.1:8032");
		conf.set("yarn.resourcemanager.scheduler.address", "192.168.0.1:8030");
		
		return conf;
		
	}
	
}
