package demo;

import java.io.IOException;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


//TextOutputFormat<K, V>
public  class KNNResultformat{
	public  static class writeKNNResultformat extends FileOutputFormat<Text, Text>{
		public writeKNNResultformat(){

		}

		@Override
		public RecordWriter<Text, Text> getRecordWriter(
				TaskAttemptContext job) throws IOException, InterruptedException {
			return new KNNRecordWriter(job);
		}
	}

	public static class KNNRecordWriter extends RecordWriter<Text, Text>{

		TaskAttemptContext job;
		FileSystem fs = null;

		FSDataOutputStream versicolor = null;
		FSDataOutputStream virginica = null;
		FSDataOutputStream setosa = null;

		public KNNRecordWriter(){

		}
		public KNNRecordWriter(TaskAttemptContext job){
			this.job=job;
			try{
			fs=FileSystem.newInstance(job.getConfiguration()); 
			versicolor=fs.create(new Path("result/versicolor.txt")); 
			virginica=fs.create(new Path("result/virginica.txt"));  
			setosa=fs.create(new Path("result/setosa.txt"));  
			}catch(Exception e){
			}
		}


		@Override
		public void write(Text key, Text value) throws IOException,
		InterruptedException {
			// TODO Auto-generated method stub
			if(key.toString().contains("virginica"))  
				virginica.write((value.toString()+"\n").getBytes());  
			else if(key.toString().contains("versicolor")) 
				versicolor.write((value.toString()+"\n").getBytes());  
			else if(key.toString().contains("setosa")) 
				setosa.write((value.toString()+"\n").getBytes());  
		}

		@Override
		public void close(TaskAttemptContext context) throws IOException,
		InterruptedException {
			// TODO Auto-generated method stub
			if (versicolor!=null)   
				versicolor.close();  
			else if (virginica!=null)   
				virginica.close();  
			else if (setosa!=null)   
				setosa.close();  
		}

	}
}

