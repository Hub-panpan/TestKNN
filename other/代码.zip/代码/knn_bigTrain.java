﻿package myKnn;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class knn_bigTrain {

	public static class  knnmap  extends Mapper<LongWritable,Text,paris,Text>{
		// TODO Auto-generated method stub
		static Integer t_id;//记录标识测试数据的行号，将行号作为测试数据id
		private ArrayList<String> testData=new ArrayList<String>();//存储测试数据
		String distanceway;//得到距离计算方式

		@Override
		protected void setup(Mapper<LongWritable, Text, paris, Text>.Context context)
				throws IOException, InterruptedException {//初始化 读取全局文件和全局参数
			// TODO Auto-generated method stub
			t_id=1;
			Configuration jobconf = context.getConfiguration();
			distanceway=jobconf.get("distanceway","osjl");
			Path [] cacheFiles = context.getLocalCacheFiles();
			if (cacheFiles != null && cacheFiles.length > 0) {
				BufferedReader joinReader = new BufferedReader(
						new FileReader(cacheFiles[0].toString()));
				try{    
					String line=null;
					while ((line = joinReader.readLine()) != null) {	
						testData.add(line);
					}
				} finally {  joinReader.close(); }
				super.setup(context);
			}
		}

		@Override
		protected void map(LongWritable key, Text value,
				Mapper<LongWritable, Text, paris, Text>.Context context)
						throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			String train_data=value.toString();
			String[] rc1=train_data.split(",");//文件是csv格式的，使用','分割开
			String type=rc1[rc1.length-1];

			for(String i : testData){
				String[] rc2=i.split(",");
				Double dis=getdistance(rc1, rc2,distanceway);//计算距离
				context.write(new paris(t_id,dis), new Text(type));//使用自定数据类型写出
				t_id++;
			}
			t_id=1;//重置行号
		}
	}

	public static class knncombiner extends Reducer<paris, Text, paris, Text>{
		static int k;//全局参数k														
		int j;			//当前id剩余数据量
		Integer currentt_id;//当前id

		public void setup(Context context) {//初始化变量
			Configuration jobconf = context.getConfiguration();
			k = jobconf.getInt("k", 5); 
			currentt_id=null;
			j=k;
		}

		@Override
		protected void reduce(paris key, Iterable<Text> value,
				Reducer<paris, Text, paris, Text>.Context context)
						throws IOException, InterruptedException {
			if(currentt_id==null)//考虑到第一次运行
				currentt_id=key.t_id;

			if(currentt_id!=key.t_id){//测试数据id变更就重置j和当前id
				j=k;
				currentt_id=key.t_id;
			}

			if(j!=0)//限制每个id只写出k条数据
				for(Text i:value){//考虑到距离相同的情况
					j--;
					context.write(key, i);
					if(j==0)
						break;
				}
		}
	}

	public static class knnreduce extends Reducer<paris, Text, Text, NullWritable>{

		static int k;//全局参数限制量top k
		String distanceway;//距离计算方式
		int j;//当前id剩余量
		HashMap<String, Integer>  hm;//存储类标签和对应的次数
		Integer currentt_id;

		double right_count;//存储与检验文件相同的数量
		double false_count;//存储于检验文件不同的数量
		private ArrayList<String> lableData=new ArrayList<String>();//读取检验文件用于正确率的计算

		public void setup(Context context) throws IOException, InterruptedException {	
			Configuration jobconf = context.getConfiguration();//初始化变量
			k = jobconf.getInt("k", 5); 
			distanceway=jobconf.get("distanceway","osjl");//默认距离计算方式欧式距离
			hm=new HashMap<String, Integer>();  
			currentt_id=null;
			j=k;

			right_count=0;
			false_count=0;
			Path [] cacheFiles = context.getLocalCacheFiles();
			if (cacheFiles != null && cacheFiles.length > 0) {
				BufferedReader joinReader = new BufferedReader(
						new FileReader(cacheFiles[1].toString()));
				try{    
					String line=null;
					while ((line = joinReader.readLine()) != null) {	
						lableData.add(line.trim());
					}
				} finally {  joinReader.close(); }
				super.setup(context);
			}
		}

		@Override
		protected void reduce(paris key, Iterable<Text> value,
				Reducer<paris, Text, Text, NullWritable>.Context context)
						throws IOException, InterruptedException {

			if(currentt_id==null)//考虑第一次运行
				currentt_id=key.t_id;

			if(currentt_id!=key.t_id){//id变更修改当前id剩余量，改变当前id
				j=k;
				currentt_id=key.t_id;
			}

			if(j!=0)//控制前k条数据进行运算
				for(Text i:value){//考虑距离一样的情况
					Integer count=1;
					if(hm.containsKey(i.toString()))
						count+=hm.get(i.toString());
					hm.put(i.toString(), count);//更新类别对应的计数
					j--;
					if(j==0){//id对应的前k条数据录入完毕，计算投票的结果
						String newkey=getvalue(hm, 1).trim();
						context.write(new Text(newkey), NullWritable.get());//写出类别预测结果
						hm.clear();
						if(lableData.get((int) (false_count+right_count)).equals(newkey))
							right_count+=1;//计算预测效果和真实效果的差别数
						else
							false_count+=1;
					}
				}}

		@Override
		protected void cleanup(
				Reducer<paris, Text, Text, NullWritable>.Context context)
						throws IOException, InterruptedException {
			// TODO Auto-generated method stub//写出预测的结果和一些参数设置情况
			context.write(new Text("距离计算方式:"+distanceway), NullWritable.get());
			context.write(new Text("k:"+k), NullWritable.get());
			context.write(new Text("准确率:"+right_count/(right_count+false_count)), NullWritable.get());
		}
	}

	public static String getvalue(HashMap<String, Integer> tmp,int k) {//在reduce中的k个中按照统计得到的个数排序，取出第一条数据
		List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(tmp.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return -o1.getValue().compareTo(o2.getValue());
			}
		});
		for (Map.Entry<String, Integer> mapping : list) {
			return mapping.getKey();
		}
		return "";
	}

	public static double  getdistance(String[] rc1,String[] rc2,String distanceway){//实现两种距离计算方式
		double sum=0;
		for(int m=0;m<rc2.length;m++){
			switch(distanceway){
			case "osjl":sum+=Math.pow(new Double(rc1[m])-new Double(rc2[m]), 2);//欧氏距离计算
			break;
			case "mhd":sum+=Math.abs(new Double(rc1[m])-new Double(rc2[m]));//曼哈顿距离计算
			}
		}
		if(distanceway.equals("osjl"))
			sum=Math.sqrt(sum);
		return sum;
	}

	public static class paris implements WritableComparable<paris>{

		Integer t_id;//测试数据id
		Double dis;//距离

		public paris(){

		}

		public paris(Integer t_id, Double dis) {
			super();
			this.t_id = t_id;
			this.dis = dis;
		}

		@Override
		public void write(DataOutput out) throws IOException {
			// TODO Auto-generated method stub
			out.writeInt(t_id);
			out.writeDouble(dis);
		}

		@Override
		public void readFields(DataInput in) throws IOException {
			// TODO Auto-generated method stub
			t_id=in.readInt();
			dis=in.readDouble();
		}

		@Override
		public int compareTo(paris o) {//实现compare完成特定的排序
			if(o.t_id.equals(t_id))//先比较测试数据的id
				return dis.compareTo(o.dis);//再比较距离
			return t_id.compareTo(o.t_id);
		}

		@Override
		public boolean equals(Object o) {
			// TODO Auto-generated method stub
			paris i=(paris) o;
			return i.compareTo(this)==0;//判断是否相等，考虑出现距离相等的情况
		}

		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return t_id.hashCode();//返回测数据的id的hash，将同一个id的发送到同一个reduce
		}

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return t_id.toString()+":"+dis.toString();
		}
	}

	public static void main(String[] args)  throws Exception{
		//for args
		String[] otherArgs = new String[6]; 
		if(args.length!=6){
			otherArgs[0] = "hdfs://192.168.0.1:8020/user/acrush/newdata/iris_train.csv";        
			String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());        
			otherArgs[1] = "hdfs://192.168.0.1:8020/user/acrush/result/out_knn"+time;
			otherArgs[2]="newdata/iris_test_data.csv";
			otherArgs[3]="5";
			otherArgs[4]="newdata/iris_test_lable.csv";
			otherArgs[5]="osjl";
		}
		//for commit
		File jarFile = EJob.createTempJar("bin");        
		ClassLoader classLoader = EJob.getClassLoader();        
		Thread.currentThread().setContextClassLoader(classLoader); 
		//args
		Configuration conf = anyConf.getBasicConf();
		conf.setInt("k",  Integer.parseInt(otherArgs[3]));
		conf.set("distanceway", otherArgs[5]);
		//job   first job
		Job job = Job.getInstance(conf, "knn");
		job.setJarByClass(knn_bigTrain.class);  
		((JobConf) job.getConfiguration()).setJar(jarFile.toString());
		job.setMapperClass(knnmap.class);
		job.setReducerClass(knnreduce.class);
		job.setCombinerClass(knncombiner.class);
		job.addCacheFile(new Path(otherArgs[2]).toUri());
		job.addCacheFile(new Path(otherArgs[4]).toUri());
		job.setOutputKeyClass(paris.class);        
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPaths(job, otherArgs[0]); 
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

		if(job.waitForCompletion(true)){
			System.out.println("success");
		}
	}
}
