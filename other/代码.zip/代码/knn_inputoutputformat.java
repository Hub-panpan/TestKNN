package myKnn;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class knn_inputoutputformat {

	public static class  knnmap  extends Mapper<Text,Text,paris,Text>{
		// TODO Auto-generated method stub
		static Integer t_id;
		private ArrayList<String> testData=new ArrayList<String>();
		String distanceway;

		@Override
		protected void setup(Mapper<Text, Text, paris, Text>.Context context)
				throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			t_id=1;
			Configuration jobconf = context.getConfiguration();
			distanceway=jobconf.get("distanceway","osjl");
			Path [] cacheFiles = context.getLocalCacheFiles();
			if (cacheFiles != null && cacheFiles.length > 0) {
				BufferedReader joinReader = new BufferedReader(
						new FileReader(cacheFiles[0].toString()));
				try{    
					String line=null;
					while ((line = joinReader.readLine()) != null) {	
						testData.add(line);
					}
				} finally {  joinReader.close(); }
				super.setup(context);
			}}

		@Override
		protected void map(Text key, Text value,
				Mapper<Text, Text, paris, Text>.Context context)
						throws IOException, InterruptedException {
			// TODO Auto-generated method stub

			for(String i : testData){
				String[] rc2=i.split(",");
				Double dis=getdistance(value.toString().split(","), rc2,distanceway);
				context.write(new paris(t_id,dis,i), new Text(key.toString()));
				t_id++;
			}
			t_id=1;
		}
	}

	public static class knncombiner extends Reducer<paris, Text, paris, Text>{
		static int k;
		int j;
		Integer currentt_id;

		public void setup(Context context) {	
			Configuration jobconf = context.getConfiguration();
			k = jobconf.getInt("k", 5); 
			currentt_id=null;
			j=k;
		}

		@Override
		protected void reduce(paris key, Iterable<Text> value,
				Reducer<paris, Text, paris, Text>.Context context)
						throws IOException, InterruptedException {
			if(currentt_id==null)
				currentt_id=key.t_id;

			if(currentt_id!=key.t_id){
				j=k;
				currentt_id=key.t_id;
			}

			if(j!=0)
				for(Text i:value){
					j--;
					context.write(key, i);
					if(j==0)
						break;
				}
		}
	}

	public static class knnreduce extends Reducer<paris, Text, Text, Text>{

		static int k;
		String distanceway;
		int j;
		HashMap<String, Integer>  hm;
		Integer currentt_id;

		double right_count;
		double false_count;
		private ArrayList<String> lableData=new ArrayList<String>();

		public void setup(Context context) throws IOException, InterruptedException {	
			Configuration jobconf = context.getConfiguration();
			k = jobconf.getInt("k", 5); 
			distanceway=jobconf.get("distanceway","osjl");
			hm=new HashMap<String, Integer>();  
			currentt_id=null;
			j=k;

			right_count=0;
			false_count=0;
			Path [] cacheFiles = context.getLocalCacheFiles();
			if (cacheFiles != null && cacheFiles.length > 0) {
				BufferedReader joinReader = new BufferedReader(
						new FileReader(cacheFiles[1].toString()));
				try{    
					String line=null;
					while ((line = joinReader.readLine()) != null) {	
						lableData.add(line.trim());
					}
				} finally {  joinReader.close(); }
				super.setup(context);
			}
		}

		@Override
		protected void reduce(paris key, Iterable<Text> value,
				Reducer<paris, Text, Text, Text>.Context context)
						throws IOException, InterruptedException {

			if(currentt_id==null)
				currentt_id=key.t_id;

			if(currentt_id!=key.t_id){
				j=k;
				currentt_id=key.t_id;
			}

			if(j!=0)
				for(Text i:value){
					Integer count=1;
					if(hm.containsKey(i.toString()))
						count+=hm.get(i.toString());
					hm.put(i.toString(), count);
					j--;
					if(j==0){
						String newkey=getvalue(hm, 1).trim();
						context.write(new Text(newkey.trim()),new Text(key.sourcedata));
						hm.clear();
						if(lableData.get((int) (false_count+right_count)).equals(newkey))
							right_count+=1;
						else
							false_count+=1;
					}
				}}
	}

	public static String getvalue(HashMap<String, Integer> tmp,int k) {
		List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(tmp.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return -o1.getValue().compareTo(o2.getValue());
			}
		});
		for (Map.Entry<String, Integer> mapping : list) {
			return mapping.getKey();
		}
		return "";
	}

	public static double  getdistance(String[] rc1,String[] rc2,String distanceway){
		double sum=0;
		for(int m=0;m<rc2.length;m++){
			switch(distanceway){
			case "osjl":sum+=Math.pow(new Double(rc1[m])-new Double(rc2[m]), 2);
			break;
			case "mhd":sum+=Math.abs(new Double(rc1[m])-new Double(rc2[m]));
			}
		}
		if(distanceway.equals("osjl"))
			sum=Math.sqrt(sum);
		return sum;
	}

	public static class paris implements WritableComparable<paris>{

		Integer t_id;
		Double dis;
		String sourcedata;

		public paris(){

		}

		public paris(Integer t_id, Double dis,String source) {
			super();
			this.t_id = t_id;
			this.dis = dis;
			this.sourcedata=source;
		}

		@Override
		public void write(DataOutput out) throws IOException {
			// TODO Auto-generated method stub
			out.writeInt(t_id);
			out.writeDouble(dis);
			out.writeUTF(sourcedata);
		}

		@Override
		public void readFields(DataInput in) throws IOException {
			// TODO Auto-generated method stub
			t_id=in.readInt();
			dis=in.readDouble();
			sourcedata=in.readUTF();
		}

		@Override
		public int compareTo(paris o) {
			if(o.t_id.equals(t_id))
				return dis.compareTo(o.dis);
			return t_id.compareTo(o.t_id);
		}

		@Override
		public boolean equals(Object o) {
			// TODO Auto-generated method stub
			paris i=(paris) o;
			return i.compareTo(this)==0;
		}

		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return t_id.hashCode();
		}

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return t_id.toString()+":"+dis.toString();
		}
	}

	public static void main(String[] args)  throws Exception{
		//for args
		String[] otherArgs = new String[6]; 
		if(args.length!=6){
			otherArgs[0] = "hdfs://192.168.0.1:8020/user/acrush/newdata/iris_train.csv";        
			String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());        
			otherArgs[1] = "hdfs://192.168.0.1:8020/user/acrush/result/out_knn"+time;
			otherArgs[2]="newdata/iris_test_data.csv";
			otherArgs[3]="30";
			otherArgs[4]="newdata/iris_test_lable.csv";
			otherArgs[5]="osjl";
		}
		//for commit
		File jarFile = EJob.createTempJar("bin");        
		ClassLoader classLoader = EJob.getClassLoader();        
		Thread.currentThread().setContextClassLoader(classLoader); 
		//args
		Configuration conf = anyConf.getBasicConf();
		conf.setInt("k",  Integer.parseInt(otherArgs[3]));
		conf.set("distanceway", otherArgs[5]);
		//job   first job
		Job job = Job.getInstance(conf, "knn");
		job.setJarByClass(knn_inputoutputformat.class);  
		((JobConf) job.getConfiguration()).setJar(jarFile.toString());
		job.setMapperClass(knnmap.class);
		job.setReducerClass(knnreduce.class);
		job.setCombinerClass(knncombiner.class);
		job.addCacheFile(new Path(otherArgs[2]).toUri());
		job.addCacheFile(new Path(otherArgs[4]).toUri());
		job.setOutputKeyClass(paris.class);        
		job.setOutputValueClass(Text.class);
		job.setInputFormatClass(ReadKNNFile.KNNFileinputformat.class);
		job.setOutputFormatClass(KNNResultformat.writeKNNResultformat.class);

		FileInputFormat.addInputPaths(job, otherArgs[0]); 
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

		if(job.waitForCompletion(true)){
			System.out.println("success");
		}
	}
}
