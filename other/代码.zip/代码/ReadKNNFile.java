package myKnn;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.util.LineReader;


public class ReadKNNFile  {

	//  TextInputFormat.class;
	//  CombineFileInputFormat<K, V>;
	//  KeyValueTextInputFormat;
	//  SequenceFileInputFormat;

	public static class KNNFileinputformat extends FileInputFormat<Text, Text>{

		@Override
		public RecordReader<Text, Text> createRecordReader(InputSplit split,
				TaskAttemptContext context) throws IOException,
				InterruptedException {
			return new KNNFileRecordReader();
		}

	}


	public static class KNNFileRecordReader extends RecordReader<Text, Text>{

		private FileSplit fs ;
		private Text value;
		private Text key;
		private LineReader reader;


		@Override
		public void initialize(InputSplit split, TaskAttemptContext context)
				throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			fs = (FileSplit) split;
			Path path = fs.getPath();
			Configuration conf = new Configuration();
			FileSystem system = path.getFileSystem(conf);
			FSDataInputStream in = system.open(path);
			reader = new LineReader(in);
		}


		@Override
		public boolean nextKeyValue() throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			Text tmp = new Text();
			int length ;
			if((length=reader.readLine(tmp))!=0){
				String[] tmp2=tmp.toString().split(",");
				key=new Text(tmp2[tmp2.length-1]);
				value=new Text(tmp.toString().split(key.toString())[0]);
			}

			return tmp.toString().isEmpty() ? false :true;
		}

		@Override
		public Text getCurrentValue() throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			return this.value;
		}

		@Override
		public Text getCurrentKey() throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			return this.key;
		}
		@Override
		public float getProgress() throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public void close() throws IOException {
			// TODO Auto-generated method stub

		}

	}

}